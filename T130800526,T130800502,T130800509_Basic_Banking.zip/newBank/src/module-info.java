/**
 * 
 */
/**
 * 
 */
module BankingJDBC {
	requires java.sql;
}