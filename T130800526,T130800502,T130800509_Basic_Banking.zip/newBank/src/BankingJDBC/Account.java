package BankingJDBC;

public class Account {
    private String firstName;
    private String lastName;
    private String accId;
    private double balance;
    private int passcode;

    public Account(String firstName, String lastName, String accId, double balance, int passcode) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.accId = accId;
        this.balance = balance;
        this.passcode = passcode;
    }


    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getAccId() { return accId; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
    public int getPasscode() { return passcode; }
    public void setPasscode(int passcode) { this.passcode = passcode; }
}