package BankingJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class CreateAccount {
    
    public static Account create(ArrayList<Account> accounts, Scanner scanner) {
        System.out.println("Enter First name:");
        String firstName = scanner.nextLine();
        System.out.println("Enter Last name:");
        String lastName = scanner.nextLine();
        System.out.println("Enter Balance:");
        double balance = scanner.nextDouble();
        System.out.println("Enter passcode:");
        int passcode = scanner.nextInt();
        System.out.println("Confirm passcode:");
        int confirm = scanner.nextInt();

        if (passcode != confirm) {
            System.out.println("Passcode mismatch!");
            return null;
        }

        // Generate unique alphanumeric account ID (6 characters)
        String id = generateUniqueAccountId();
        if (id == null) {
            System.out.println("Error: Could not generate account ID!");
            return null;
        }

        Account acc = new Account(firstName, lastName, id, balance, passcode);
        accounts.add(acc);

        try (Connection conn = Database.connect()) {
            if (conn == null) {
                System.out.println("Error: Could not connect to database!");
                return null;
            }
            String sql = "INSERT INTO accounts (accId, firstName, lastName, balance, passcode) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setDouble(4, balance);
            stmt.setInt(5, passcode);
            stmt.executeUpdate();
            System.out.println("\nAccount created successfully!");
            System.out.println("Your Account ID: " + id);
            System.out.println("Account saved to database!");
        } catch (SQLException e) {
            System.out.println("Error saving account: " + e.getMessage());
            return null;
        }

        return acc;
    }

    private static String generateUniqueAccountId() {
        Random random = new Random();
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        int maxAttempts = 100;
        
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            StringBuilder id = new StringBuilder();
            for (int i = 0; i < 6; i++) {
                id.append(characters.charAt(random.nextInt(characters.length())));
            }
            String generatedId = id.toString();
            
            // Check if ID already exists in database
            if (!accountIdExists(generatedId)) {
                return generatedId;
            }
        }
        
        return null; // Could not generate unique ID after max attempts
    }
    
    private static boolean accountIdExists(String accId) {
        try (Connection conn = Database.connect()) {
            if (conn == null) {
                return true; // Assume exists if can't connect
            }
            String sql = "SELECT COUNT(*) FROM accounts WHERE accId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, accId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (SQLException e) {
            System.out.println("Error checking account ID: " + e.getMessage());
            return true; // Assume exists on error
        }
    }
}