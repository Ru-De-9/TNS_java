package BankingJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Withdraw extends Transaction {

    public Withdraw(Account account, java.util.Scanner scanner) {
        super(account, scanner);
    }

    @Override
    public void execute() {
        System.out.println("Enter amount to withdraw:");
        double amount = scanner.nextDouble();

        if (amount > account.getBalance()) {
            System.out.println("Insufficient balance!");
        } else {
            account.setBalance(account.getBalance() - amount);
            System.out.println("Withdrawal successful! New balance: " + account.getBalance());

            //  Database updates here
            try (Connection conn = Database.connect()) {
                if (conn == null) {
                    System.out.println("Error: Could not connect to database!");
                    return;
                }
                String sql = "UPDATE accounts SET balance = ? WHERE accId = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setDouble(1, account.getBalance());
                stmt.setString(2, account.getAccId());
                stmt.executeUpdate();
                System.out.println("Database updated!");
            } catch (Exception e) {
                System.out.println("Error updating balance: " + e.getMessage());
            }
        }
    }
}