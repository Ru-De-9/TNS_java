package BankingJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Menu {
    public static void show(Account acc, Scanner scanner) {
        int choice;
        do {
            System.out.println("\nWelcome " + acc.getFirstName() + " " + acc.getLastName() + " (ID: " + acc.getAccId() + ")");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Change PIN");
            System.out.println("5. Logout");
            choice = scanner.nextInt();

            switch(choice) {
                case 1: 
                    System.out.println("Balance: " + acc.getBalance()); 
                    break;
                case 2: 
                    Transaction deposit = new Deposit(acc, scanner); // polymorphism
                    deposit.execute();
                    break;
                case 3: 
                    Transaction withdraw = new Withdraw(acc, scanner); // polymorphism
                    withdraw.execute();
                    break;
                case 4:
                    changePin(acc, scanner);
                    break;
                case 5: 
                    System.out.println("Logging out...");
                    break;
                default: 
                    System.out.println("Invalid choice!");
            }
        } while(choice != 5);
    }
    
    private static void changePin(Account acc, Scanner scanner) {
        System.out.println("Enter current PIN:");
        int currentPin = scanner.nextInt();
        
        if (currentPin != acc.getPasscode()) {
            System.out.println("Incorrect current PIN!");
            return;
        }
        
        System.out.println("Enter new PIN:");
        int newPin = scanner.nextInt();
        System.out.println("Confirm new PIN:");
        int confirmPin = scanner.nextInt();
        
        if (newPin != confirmPin) {
            System.out.println("PIN mismatch! PIN not changed.");
            return;
        }
        
        try (Connection conn = Database.connect()) {
            if (conn == null) {
                System.out.println("Error: Could not connect to database!");
                return;
            }
            String sql = "UPDATE accounts SET passcode = ? WHERE accId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, newPin);
            stmt.setString(2, acc.getAccId());
            int rowsUpdated = stmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                acc.setPasscode(newPin);
                System.out.println("PIN changed successfully!");
            } else {
                System.out.println("Error: PIN could not be updated!");
            }
        } catch (Exception e) {
            System.out.println("Error changing PIN: " + e.getMessage());
        }
    }
}