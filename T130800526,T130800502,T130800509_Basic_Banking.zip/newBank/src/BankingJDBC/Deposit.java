package BankingJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Deposit extends Transaction {

    public Deposit(Account account, java.util.Scanner scanner) {
        super(account, scanner);
    }

    @Override
    public void execute() {
        System.out.println("Enter amount to deposit:");
        double amount = scanner.nextDouble();
        account.setBalance(account.getBalance() + amount);
        System.out.println("Deposit successful! New balance: " + account.getBalance());

        // Database updating 
        try (Connection conn = Database.connect()) {
            if (conn == null) {
                System.out.println("Error: Could not connect to database!");
                return;
            }
            String sql = "UPDATE accounts SET balance = ? WHERE accId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDouble(1, account.getBalance());
            stmt.setString(2, account.getAccId());
            stmt.executeUpdate();
            System.out.println("Database updated!");
        } catch (Exception e) {
            System.out.println("Error updating balance: " + e.getMessage());
        }
    }
}