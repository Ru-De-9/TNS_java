package BankingJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

public class Login {
    public static Account login(ArrayList<Account> accounts, Scanner scanner) {
        System.out.println("Enter account id:");
        String id = scanner.next();
        System.out.println("Enter passcode:");
        int passcode = scanner.nextInt();

        try (Connection conn = Database.connect()) {
            if (conn == null) {
                System.out.println("Error: Could not connect to database!");
                return null;
            }
            String sql = "SELECT * FROM accounts WHERE accId = ? AND passcode = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setInt(2, passcode);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Account acc = new Account(
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("accId"),
                    rs.getDouble("balance"),
                    rs.getInt("passcode")
                );
                System.out.println("Login successful!");
                return acc;
            } else {
                System.out.println("Invalid credentials!");
                return null;
            }
        } catch (Exception e) {
            System.out.println("Error during login: " + e.getMessage());
            return null;
        }
    }
}