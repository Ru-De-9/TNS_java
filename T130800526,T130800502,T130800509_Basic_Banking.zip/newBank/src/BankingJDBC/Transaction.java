package BankingJDBC;

import java.util.Scanner;

public abstract class Transaction {
    protected Account account;
    protected Scanner scanner;

    public Transaction(Account account, Scanner scanner) {
        this.account = account;
        this.scanner = scanner;
    }

    public abstract void execute();
}