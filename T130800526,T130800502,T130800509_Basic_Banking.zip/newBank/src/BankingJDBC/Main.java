package BankingJDBC;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static ArrayList<Account> accounts = new ArrayList<>();

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\nWelcome to Bank");
            System.out.println("1. Create Account");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            choice = scanner.nextInt();

            switch (choice) {
                case 1 -> {
                    scanner.nextLine(); 
                    Account acc = CreateAccount.create(accounts, scanner);
                    if (acc != null) Menu.show(acc, scanner);
                }
                case 2 -> {
                    Account logged = Login.login(accounts, scanner);
                    if (logged != null) Menu.show(logged, scanner);
                }
                case 3 -> System.out.println("Goodbye!");
                default -> System.out.println("Invalid choice!");
            }
        } while(choice != 3);
    }
}