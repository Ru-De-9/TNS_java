// portfolio data
const profile = {
  roles: [
    'An Aspiring Web-Developer,',
    'Frontend Engineer,',
    'Backend Enthusiast.'
  ],
  navLinks: [
     { label: 'Home', href: '#hero' },
    { label: 'About Me', href: '#about' },
    { label: 'Skills', href: '#skills' },
    { label: 'Projects', href: '#projects' },
    { label: 'Contact Me', href: '#contact' }
  ],
  skills: ['HTML', 'CSS', 'JavaScript', 'Java', 'MySQL', 'MongoDB'],
  projects: [
    {
      title: 'Portfolio Website',
      description:
        'A responsive portfolio showcasing my skills, projects, and contact information.'
    },
    {
      title: 'Documentation Portal',
      description:
        'Developed an AI-integrated smart portal which generates and stores all the required documents during college events.'
    },
    {
      title: 'Banking System ',
      description:
        'Created a purely Java-based Banking System that showcases OOP concepts.'
    }
  ],
  contacts: [
    {
      label: 'Email',
      text: 'your-email@gmail.com',
      href: 'gmail link'
    },
    {
      label: 'LinkedIn',
      text: 'Connect with me',
      href: 'https://www.linkedin.com/in/rucha-desai-a40574331/?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app'
    },
    {
      label: 'GitHub',
      text: 'My Projects',
      href: 'https://github.com/Ru-De-9/TNS_java'
    }
  ],
  resume: {
    resumeFile: 'dummyfile.txt',  //name of ur resume pdf file
    cvFile: 'dummyfile.txt'   //name of ur cv pdf file
  }
};


// nav links
const navUl = document.getElementById('navLinks');
navUl.innerHTML = profile.navLinks
  .map((link) => `<li><a href="${link.href}">${link.label}</a></li>`)
  .join('');


// skills
const skillsList = document.getElementById('skills-list');
skillsList.innerHTML = profile.skills
  .map((skill) => `<div class="skill">${skill}</div>`)
  .join('');


// projects (dynamic loader style)
const projectsGrid = document.getElementById('projectsGrid');
projectsGrid.innerHTML = profile.projects
  .map(
    (project) => `
      <article class="projectCard">
        <h3>${project.title}</h3>
        <p>${project.description}</p>
      </article>
    `
  )
  .join('');

// contact links (direct redirects)
const contactList = document.getElementById('contactList');
contactList.innerHTML = profile.contacts
  .map(
    (contact) => `
      <li>
        <strong>${contact.label}:</strong>
        <a href="${contact.href}" target="_blank" rel="noreferrer">
          ${contact.text}
        </a>
      </li>
    `
  )
  .join('');

// download buttons
const downloadButtons = document.getElementById('downloadButtons');
if (downloadButtons) {
  downloadButtons.innerHTML = `
    <div class="download-buttons">
      <a href="${profile.resume.resumeFile}" download class="download-btn resume-btn">Download Resume</a>
      <a href="${profile.resume.cvFile}" download class="download-btn cv-btn">Download CV</a>
    </div>
  `;
}

// Smooth scroll with offset for navbar
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      const navHeight = document.querySelector('nav').offsetHeight;
      const targetPosition = target.offsetTop - navHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  });
});

// Typed.js initialization for the home text
new Typed('#element', {
  strings: profile.roles,
  typeSpeed: 50,
  backSpeed: 30,
  loop: true
});